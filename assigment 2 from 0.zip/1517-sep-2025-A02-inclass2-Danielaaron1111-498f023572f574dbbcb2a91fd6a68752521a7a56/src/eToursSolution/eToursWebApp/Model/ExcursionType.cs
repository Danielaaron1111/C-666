﻿namespace eToursWebApp.Model
{
    public enum ExcursionType
    {
        Walk,
        BusTour,
        Bike,
        Water,
        Dive,
        Moped
    }
}
