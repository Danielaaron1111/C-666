[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/EWNsANLn)
# CPSC1517-1251 In-Class Assessment 2 - Razor Pages ![Weight - 15%](https://img.shields.io/badge/Weight-15%20%25%20-darkgreen?logo=OpenAPI-Initiative&style=for-the-badge)

## Student Name: your name here

**This assessment is to be an individual effort. Collaboration is not allowed. Collaboration would be an academic integrity concern. Artificial Intelligence (AI) code generation is not allowed. AI code generation would be an academic integrity concern.**

**You may have access to the following github repositories: your classroom workbook, your exercise 3, and your instructor classroom workbook.**

There are two sections to this assessment: theory multiple choice questions and practical coding specifications. The links below take you to each section.

1. Multiple Choice question are found in the BrightSpace link.
1. [Coding Specifications](./Questions/Coding.md)
